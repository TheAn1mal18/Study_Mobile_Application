# Study_Mobile_Application
This application is made for multiple study purposes and will include flashcards and a quiz which will be completely editable and infinitley usable.
# In Progress
1. working on the quiz editor
2. need to implement database to hold saved quizzes
3. need to implement the fragment to edit and create databases
