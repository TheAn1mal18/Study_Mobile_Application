package com.example.studyapplication.ui.viewmodel

import androidx.lifecycle.*
import com.example.studyapplication.data.QuizzersDao
import com.example.studyapplication.model.Quiz
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class QuizzersViewModel(
    private val quizzersDao: QuizzersDao
): ViewModel() {

    val allQuizzes: LiveData<List<Quiz>> = quizzersDao.getQuizzes().asLiveData()

    fun getQuizzesById(id: Long){
        return quizzersDao.getQuizzesById(id).asLiveData()
    }

    fun addQuiz(
        question: String,
        answers: List<String>,
        taken: Boolean,
        description: String
    ){
        val quiz = Quiz(
            question = question,
            answers = answers,
            taken = taken,
            description = description
        )

        viewModelScope.launch {
            quizzersDao.insert(quiz)
        }
    }

    fun updateQuiz(
        question: String,
        answers: List<String>,
        taken: Boolean,
        description: String
    ){
        val quiz = Quiz(
            question = question,
            answers = answers,
            taken = taken,
            description = description
        )

        viewModelScope.launch(Dispatchers.IO) {
            quizzersDao.update(quiz)
        }
    }

    fun deleteQuiz(quiz: Quiz){
        viewModelScope.launch(Dispatchers.IO) {
            quizzersDao.delete(quiz)
        }
    }

    fun isValidEntry(question: String, answer1: String, answer2: String,
    answer3: String, answer4: String): Boolean{
        return question.isNotBlank() && answer1.isNotBlank() && answer2.isNotBlank() && answer3.isNotBlank() && answer4.isNotBlank()
    }
}

class QuizzersViewModelFactory(private val quizzersDao: QuizzersDao): ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(QuizzersViewModel::class.java)){
            return QuizzersViewModel(quizzersDao) as T
        }

        throw IllegalArgumentException("Unknown ViewModel Class")
    }
}