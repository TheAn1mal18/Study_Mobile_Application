package com.example.studyapplication.ui

class MenuFragment {
}