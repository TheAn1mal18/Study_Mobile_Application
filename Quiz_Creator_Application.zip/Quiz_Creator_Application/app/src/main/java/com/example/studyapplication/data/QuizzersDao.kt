package com.example.studyapplication.data

import androidx.room.*
import com.example.studyapplication.model.Quiz
import kotlinx.coroutines.flow.Flow

@Dao
interface QuizzersDao {
    @Query("SELECT * FROM quizzes_database")
    fun getQuizzes(): Flow<List<Quiz>>

    @Query("SELECT * FROM quizzes_database WHERE id = :id")
    fun getQuizzesById(id: Long): Flow<Quiz>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(quiz: Quiz)

    @Update
    suspend fun update(quiz: Quiz)

    @Delete
    suspend fun delete(quiz: Quiz)
}