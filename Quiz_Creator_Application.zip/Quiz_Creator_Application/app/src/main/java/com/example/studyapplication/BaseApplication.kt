package com.example.studyapplication

import android.app.Application
import com.example.studyapplication.data.QuizzersDatabase

class BaseApplication: Application() {
    val database: QuizzersDatabase by lazy {
        QuizzersDatabase.getDatabase(this)
    }
}