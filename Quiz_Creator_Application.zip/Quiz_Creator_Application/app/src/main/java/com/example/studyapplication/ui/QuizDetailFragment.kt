package com.example.studyapplication.ui

class QuizDetailFragment {
}