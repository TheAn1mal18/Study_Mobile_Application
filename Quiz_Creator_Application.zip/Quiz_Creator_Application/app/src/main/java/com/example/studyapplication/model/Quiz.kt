package com.example.studyapplication.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

//Questions will be organized in the list (Answer, WrongQuestion1, WrongQuestion2, WrongQuestion3)
@Entity(tableName = "quizzes_database")
data class Quiz(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val question: String,
    val answers: List<String>,
    @ColumnInfo(name = "already_taken")
    val taken: Boolean,
    val description: String
)
