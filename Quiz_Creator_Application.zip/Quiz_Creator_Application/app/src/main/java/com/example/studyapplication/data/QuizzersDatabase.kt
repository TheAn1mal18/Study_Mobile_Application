package com.example.studyapplication.data

import androidx.room.RoomDatabase

abstract class QuizzersDatabase : RoomDatabase() {

    companion object{

    }
}