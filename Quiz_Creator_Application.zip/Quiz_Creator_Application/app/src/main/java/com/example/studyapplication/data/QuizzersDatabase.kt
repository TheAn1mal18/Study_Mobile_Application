package com.example.studyapplication.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.studyapplication.model.Quiz
import com.example.studyapplication.data.QuizzersDao as QuizzersDao

@Database(entities = [Quiz::class], version = 1, exportSchema = false)
abstract class QuizzersDatabase : RoomDatabase() {

    abstract fun getQuizzersDao(): QuizzersDao

    companion object{
        @Volatile
        private var INSTANCE: QuizzersDatabase? = null

        fun getDatabase(context: Context): QuizzersDatabase{
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    QuizzersDatabase::class.java,
                    "quizzers_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()

                INSTANCE = instance

                return instance
            }
        }
    }
}