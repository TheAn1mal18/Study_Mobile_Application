package com.example.studyapplication.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "quizzers_database")
data class Quizzers (
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val question: String,
    val answer: List<String>
)