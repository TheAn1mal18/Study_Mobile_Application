package com.example.studyapplication.ui

import androidx.fragment.app.Fragment

class QuizListFragment: Fragment() {

}