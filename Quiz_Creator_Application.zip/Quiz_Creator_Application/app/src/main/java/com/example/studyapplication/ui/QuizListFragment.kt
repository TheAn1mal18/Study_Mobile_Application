package com.example.studyapplication.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.studyapplication.BaseApplication
import com.example.studyapplication.R
import com.example.studyapplication.databinding.FragmentQuizListBinding
import com.example.studyapplication.model.Quiz
import com.example.studyapplication.ui.adapter.QuizzersListAdapter
import com.example.studyapplication.ui.viewmodel.QuizzersViewModel
import com.example.studyapplication.ui.viewmodel.QuizzersViewModelFactory
import java.util.zip.Inflater

class QuizListFragment: Fragment() {
    private val viewModel: QuizzersViewModel by activityViewModels {
        QuizzersViewModelFactory(
            (activity?.application as BaseApplication)
                .database.getQuizzersDao())
    }

    private var _binding: FragmentQuizListBinding? = null

    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentQuizListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = QuizzersListAdapter{ quiz ->
            val action = QuizListFragmentDirections.actionQuizListFragmentToQuizDetailFragment(quiz.id)
        }

        viewModel.allQuizzes.observe(this.viewLifecycleOwner) { quizzes ->
            quizzes.let {
                adapter.submitList(it)
            }
        }

        binding.apply {
            recyclerView.adapter = adapter
            addQuizFab.setOnClickListner{
                findNavController().navigate(
                    R.id.action_quizListFragment_to_addQuizFragment
                )
            }
        }
    }
}