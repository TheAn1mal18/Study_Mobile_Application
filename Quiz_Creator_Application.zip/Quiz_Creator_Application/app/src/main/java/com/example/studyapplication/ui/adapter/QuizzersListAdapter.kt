package com.example.studyapplication.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.studyapplication.model.Quiz

class QuizzersListAdapter(
    private val clickListener: (Quiz) -> Unit
): ListAdapter<Quiz, QuizzersListAdapter.QuizViewHolder>(DiffCallBack) {

    class QuizViewHolder(
        private var binding: ListItemQuizzersBinding
    ): RecyclerView.ViewHolder(binding.root) {

        fun bind(quiz: Quiz) {
            binding.quiz = quiz
            binding.executePendingBindings()
        }

    }

    companion object DiffCallBack: DiffUtil.ItemCallback<Quiz>() {
        override fun areItemsTheSame(oldItem: Quiz, newItem: Quiz): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Quiz, newItem: Quiz): Boolean {
             return oldItem == newItem
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuizViewHolder{
        val LayoutInflater = LayoutInflater.from(parent.context)
        return QuizViewHolder(ListItemQuizzersBinding.inflate(LayoutInflater, parent, false))
    }

    override fun onBindViewHolder(holder: QuizViewHolder, position: Int){
        val quiz = getItem(position)
        holder.itemView.setOnClickListener{
            clickListener(quiz)
        }
        holder.bind(quiz)
    }
}